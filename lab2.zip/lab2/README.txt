########################### LAB 2 README ###########################

In this Lab I attempted to make a simple little spinoff version of the
arcade classic game "pong".  In order to play this game you simply OpenGL
index.html in a browser of your choosing (it was developed in Chrome),
and press the Play button.  The ball will begin bouncing off of the walls
and it is your objective to keep the ball from hitting your own wall on
the right by using the free moving paddle.  The controls for the paddle
are as follows:

    <right arrow> or "r":   move the paddle to the right

    <left arrow> or "l":    move the paddle to the left

    <up arrow> or "f":      move the paddle upward

    <down arrow> or "b":    move the paddle downward

    <enter> or <spacebar>:  extend the paddle booster pad

The goal of the game is to see how high of a score you can get before the
ball hits your side.  If you hit the ball while the extender pad is out,
you will increase the velocity of the ball, and increase your score multiplier.
As a bonus, if you touch the far wall with your pad and hold down the
left directional arrow, you will rack up points.  But you have to hurry back
before the ball gets to your side.  Good luck.

I attempted to create a stupid little interative game with animation involved for
my bonus tasks.  Hopefully you somewhat enjoy it.

** Developed in Windows/Chrome.
